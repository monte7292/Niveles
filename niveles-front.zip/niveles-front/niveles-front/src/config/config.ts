const config = {
  apiUrl: 'https://api.niveles.xyz',
  clientUrl: 'https://niveles.xyz',
  isDev: false,
  domain: 'niveles.xyz'
};

export default config; 